import random
random.randint(1,5)
print (5/2)
# for x, y in ((a,b) for a in [1,2,3] for b in [5,6,7]):
#   print (x,y)
for a in (1,5):
    print (a)