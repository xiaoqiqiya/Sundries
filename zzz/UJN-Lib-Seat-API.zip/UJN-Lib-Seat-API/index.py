import json
import time,threading
import datetime
from libapi import * # 注意导入路径
def json_file(filename='seat.json'):
    with open(filename, 'rb') as f:
        seats_json = json.load(f)
    return seats_json

def reserve(date):
    whatday= datetime.datetime.strptime(date,'%Y-%m-%d').strftime("%w")
    if whatday=='2':
        seats = json_file('seat1.json')
    else:
        seats = json_file()
    for seat in seats:
        for user in seat['times']:
            threading.Thread(target=task, args=(user,seat,date)).start()
            ##handle(resp)
def task(user,seat,date):
    try:
       p = libapi(user['username'], user['password'])
       room_id = p.getRoomIDbyName(seat['room'])
       resp = p.book(user['begin'], user['end'], room_id, seat['seat_num'], date)
    except BaseException as w:
        print(user['username'],"====>进入重试机制")
        task(user,seat,date)
def getDate():
    try:
       p = libapi("201830121543", "zzq1162483436") # 用来获取日期
       while len(p.dates()) != 2:
           time.sleep(1)
       global divDate
       divDate = str(p.dates()[1]) 
    except BaseException:
        print('获取下一天时间发生异常正在重试')
        getDate()
    

def main():
    # p = libapi("201830121543", "zzq1162483436") # 用来获取日期
    # # p = getDate()
    # while len(p.dates()) != 2:
    #     time.sleep(1)
    # reserve(p.dates()[1])
    getDate()
    reserve(divDate)

if __name__ == '__main__':
    main()